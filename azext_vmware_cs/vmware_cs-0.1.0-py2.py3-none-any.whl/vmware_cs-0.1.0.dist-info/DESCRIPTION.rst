Microsoft Azure CLI 'vmware-cs' Extension


