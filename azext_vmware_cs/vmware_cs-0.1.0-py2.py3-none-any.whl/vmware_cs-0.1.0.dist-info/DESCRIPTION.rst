Microsoft Azure CLI 'vmware_cs' Extension


